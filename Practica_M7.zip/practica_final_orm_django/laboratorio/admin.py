from django.contrib import admin
from .models import Laboratorio, DirectorGeneral, Producto


class LaboratorioAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre') 
    search_fields = ['nombre'] 
    ordering = ['id']

class DirectorGeneralAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'laboratorio', 'especialidad') 
    search_fields = ['nombre', 'especialidad'] 
    ordering = ['id'] 


class ProductoAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'laboratorio', 'f_fabricacion', 'p_costo', 'p_venta')  
    search_fields = ['nombre'] 
    list_filter = ['nombre', 'laboratorio'] 
    ordering = ['id'] 


admin.site.register(Laboratorio, LaboratorioAdmin)
admin.site.register(DirectorGeneral, DirectorGeneralAdmin)
admin.site.register(Producto, ProductoAdmin)