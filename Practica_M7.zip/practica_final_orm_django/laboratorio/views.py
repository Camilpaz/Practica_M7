from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Laboratorio
from django.urls import reverse_lazy
from django.shortcuts import redirect
from django.contrib import messages
from django import forms
from django.shortcuts import render

  
class LaboratoriosView(ListView):
    model = Laboratorio
    template_name = "laboratorios/laboratorios.html"
    context_object_name = 'laboratorios'
    login_url = reverse_lazy('login')
    redirect_field_name = 'next'

    def get_context_data(self, **kwargs):
        if 'visit_count' in self.request.session:
            self.request.session['visit_count'] += 1
        else:
            self.request.session['visit_count'] = 1

        self.request.session.modified = True

        context = super().get_context_data(**kwargs)

        context['visit_count'] = self.request.session['visit_count']
        
        return context
    

class LaboratorioCreateView(CreateView):
    model = Laboratorio
    template_name = "laboratorios/insertar.html"
    fields = ['nombre', 'ciudad', 'pais']
    success_url = reverse_lazy('laboratorios')

    def get_context_data(self, **kwargs):
            context = super().get_context_data(**kwargs)
            return context   
    
    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        form.fields['nombre'].widget = forms.TextInput(attrs={'class': 'form-control'})
        form.fields['ciudad'].widget = forms.TextInput(attrs={'class': 'form-control'})
        form.fields['pais'].widget = forms.TextInput(attrs={'class': 'form-control'})
        return form
    
    
    

class LaboratorioDeleteView(DeleteView):
    model = Laboratorio
    template_name = "laboratorios/eliminar.html" 
    success_url = reverse_lazy('laboratorios') 


    def get_object(self, queryset=None):
        # Validar que el laboratorio exista
        obj = super().get_object(queryset)
        return obj

    def post(self, request, *args, **kwargs):
        # Confirmación de eliminación con mensaje
        laboratorio = self.get_object()
        messages.success(request, f"El laboratorio '{laboratorio.nombre}' ha sido eliminado con éxito.")
        return super().post(request, *args, **kwargs)
    
    
    
    
    

class LaboratorioUpdateView(UpdateView):
    model = Laboratorio
    template_name = "laboratorios/editar.html"
    fields = ['nombre', 'ciudad', 'pais']  
    success_url = reverse_lazy('laboratorios')  
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        return context

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        form.fields['nombre'].widget = forms.TextInput(attrs={'class': 'form-control'})
        form.fields['ciudad'].widget = forms.TextInput(attrs={'class': 'form-control'})
        form.fields['pais'].widget = forms.TextInput(attrs={'class': 'form-control'})
        return form
    
    
def laboratorios_view(request):
    # Incrementa el contador de visitas en la sesión
    if 'visit_count' in request.session:
        request.session['visit_count'] += 1
    else:
        request.session['visit_count'] = 1

    # Guarda explícitamente la sesión para asegurarte de que persiste
    request.session.modified = True

    # Imprime el valor en la consola para verificar
    print(f"Visit Count (in session): {request.session['visit_count']}")

    # Obtén la lista de laboratorios
    laboratorios = Laboratorio.objects.all()

    # Renderiza la plantilla con el contexto
    return render(request, 'laboratorios/laboratorios.html', {
        'laboratorios': laboratorios,
        'visit_count': request.session['visit_count'],  # Asegúrate de pasar el valor correctamente
    })