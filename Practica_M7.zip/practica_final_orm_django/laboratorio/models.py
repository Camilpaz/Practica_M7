from django.db import models
import datetime
# Create your models here.


    
    
class Laboratorio(models.Model):
    id= models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=50, null=False, blank=False)
    ciudad = models.CharField(max_length=50, null=True, blank=True) 
    pais = models.CharField(max_length=50, null=True, blank=True)
    
    def __str__(self):
        return f"Laboratorio: {self.nombre}"

    class Meta:
        managed =True
        db_table = 'laboratorios'
    


class DirectorGeneral(models.Model):
    id= models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=50, null=False, blank=False)
    laboratorio = models.OneToOneField(Laboratorio, on_delete=models.CASCADE, default=None, unique=True)
    especialidad = models.CharField(max_length=50, null=True, blank=True)
 

    def __str__(self):
        return f"Laboratorio: {self.laboratorio}, Director: {self.nombre}"


    class Meta:
        managed =True
        db_table = 'directores_generales'
        

def anio_actual():
    return int(datetime.date.today().year)

class Producto(models.Model):
    anios_choices=[
        (anio, str(anio)) for anio in range(2015, anio_actual()+1)
    ]
    
    id= models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    laboratorio = models.ForeignKey(Laboratorio, on_delete=models.CASCADE)
    f_fabricacion = models.IntegerField(choices=anios_choices, default=anio_actual)
    p_costo = models.DecimalField(max_digits=10, decimal_places=2, null =False, blank=False)
    p_venta = models.DecimalField(max_digits=10, decimal_places=2, null =False, blank=False)

    def __str__(self):
        return f"NOMBRE: {self.nombre}, LABORATORIO: {self.laboratorio}, , F FABRICACION: {self.f_fabricacion}, P COSTO: {self.p_costo}, P VENTA: {self.p_venta}"

    class Meta:
        managed =True
        ordering = ['f_fabricacion']
        db_table = 'productos'


